<?php phpinfo();?>
/*
admin detais:
=============
user: teqmavens
pwd: teq@123!#

Database:
=================
dbname: knotel
user: root	
pwd: root


*/
